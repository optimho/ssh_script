from setuptools import setup, find_packages

setup(
    name='fire Control',
    version='1',
    license='MIT',
    url='www.optimho.com',
    packages=find_packages(),
    author='michael',
    author_email='michael@duplessis.nz',
    description='Run scripts too enable and disable firewall rules'
)
